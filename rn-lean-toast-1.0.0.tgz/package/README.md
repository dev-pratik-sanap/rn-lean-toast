# rn-lean-toast 🍞

A blazing fast, zero-config, edge-to-edge toast library for React Native.

![npm version](https://img.shields.io/npm/v/rn-lean-toast)
![license](https://img.shields.io/npm/l/rn-lean-toast)

## Features

- **Zero-Config:** No massive Context Providers wrapping your app.
- **Edge-to-Edge Safe:** Automatically respects notches, dynamic islands, and home indicators.
- **Queue System:** Prevents overlapping by queuing multiple toasts sequentially.
- **Accessible:** Native screen-reader support out of the box.
- **Anywhere:** Trigger toasts from outside React (Redux, Axios, background tasks).

## Installation

```sh
npm install rn-lean-toast react-native-safe-area-context
```
