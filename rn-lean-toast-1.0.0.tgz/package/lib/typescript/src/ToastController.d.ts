export type ToastType = 'success' | 'error' | 'info';
export interface ToastOptions {
    message: string;
    type?: ToastType;
    duration?: number;
    backgroundColor?: string;
    textColor?: string;
}
export interface ToastData extends ToastOptions {
    id: string;
}
type Listener = (toast: ToastData | null) => void;
declare class ToastManager {
    private listener;
    private queue;
    private isDisplaying;
    private timer;
    subscribe(listener: Listener): () => void;
    show(options: ToastOptions): void;
    private processQueue;
    success(message: string, options?: Omit<ToastOptions, 'message' | 'type'>): void;
    error(message: string, options?: Omit<ToastOptions, 'message' | 'type'>): void;
    info(message: string, options?: Omit<ToastOptions, 'message' | 'type'>): void;
    hide(): void;
    next(): void;
}
export declare const Toast: ToastManager;
export {};
//# sourceMappingURL=ToastController.d.ts.map