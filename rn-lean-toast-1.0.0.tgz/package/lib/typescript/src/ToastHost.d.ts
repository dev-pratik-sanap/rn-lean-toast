export declare const ToastHost: () => import("react").JSX.Element | null;
//# sourceMappingURL=ToastHost.d.ts.map