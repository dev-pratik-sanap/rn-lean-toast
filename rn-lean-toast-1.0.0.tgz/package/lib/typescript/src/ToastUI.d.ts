import type { ToastData } from './ToastController.js';
interface ToastUIProps {
    toast: ToastData;
    isVisible: boolean;
    onAnimationEnd: () => void;
}
export declare const ToastUI: ({ toast, isVisible, onAnimationEnd }: ToastUIProps) => import("react").JSX.Element;
export {};
//# sourceMappingURL=ToastUI.d.ts.map