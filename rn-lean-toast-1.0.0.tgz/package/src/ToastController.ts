export type ToastType = 'success' | 'error' | 'info';

export interface ToastOptions {
  message: string;
  type?: ToastType;
  duration?: number;
  backgroundColor?: string;
  textColor?: string;
}

export interface ToastData extends ToastOptions {
  id: string;
}

type Listener = (toast: ToastData | null) => void;

class ToastManager {
  private listener: Listener | null = null;
  private queue: ToastData[] = [];
  private isDisplaying = false;
  private timer: NodeJS.Timeout | null = null;

  subscribe(listener: Listener) {
    this.listener = listener;
    return () => {
      this.listener = null;
    };
  }

  show(options: ToastOptions) {
    const id = Math.random().toString(36).substring(2, 9);

    // Add the new toast to the back of the line
    this.queue.push({ ...options, id });

    // If nothing is currently on screen, start the line
    if (!this.isDisplaying) {
      this.processQueue();
    }
  }

  private processQueue() {
    if (this.queue.length === 0) {
      this.isDisplaying = false;
      return;
    }

    this.isDisplaying = true;
    const currentToast = this.queue[0]!;
    const duration = currentToast.duration || 3000;

    if (this.listener) {
      this.listener(currentToast);
    }

    // Auto-hide after the duration
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      this.hide();
    }, duration);
  }

  success(message: string, options?: Omit<ToastOptions, 'message' | 'type'>) {
    this.show({ message, type: 'success', ...options });
  }

  error(message: string, options?: Omit<ToastOptions, 'message' | 'type'>) {
    this.show({ message, type: 'error', ...options });
  }

  info(message: string, options?: Omit<ToastOptions, 'message' | 'type'>) {
    this.show({ message, type: 'info', ...options });
  }

  hide() {
    // Clear the timer so it doesn't haunt the next toast in the queue
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }

    // Tell the UI to slide out
    if (this.listener) this.listener(null);
  }

  next() {
    // Called by the UI after the slide-out animation fully finishes
    this.queue.shift();
    this.processQueue();
  }
}

export const Toast = new ToastManager();
