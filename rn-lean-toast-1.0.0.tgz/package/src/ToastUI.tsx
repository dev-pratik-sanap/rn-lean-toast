import { useEffect, useRef, useState } from 'react';
import {
  Animated,
  StyleSheet,
  Text,
  PanResponder,
  type LayoutChangeEvent,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Toast } from './ToastController';
import type { ToastData } from './ToastController';

interface ToastUIProps {
  toast: ToastData;
  isVisible: boolean;
  onAnimationEnd: () => void;
}

const SWIPE_THRESHOLD = -20;
const ANIMATION_DURATION = 250;

export const ToastUI = ({ toast, isVisible, onAnimationEnd }: ToastUIProps) => {
  const insets = useSafeAreaInsets();
  const [toastHeight, setToastHeight] = useState(150);
  const translateY = useRef(new Animated.Value(-toastHeight)).current;

  useEffect(() => {
    if (isVisible) {
      Animated.spring(translateY, {
        toValue: insets.top + 10,
        useNativeDriver: true,
        bounciness: 12,
      }).start();
    } else {
      Animated.timing(translateY, {
        toValue: -(toastHeight + 50),
        duration: ANIMATION_DURATION,
        useNativeDriver: true,
      }).start(() => {
        onAnimationEnd();
      });
    }
  }, [isVisible, insets.top, translateY, onAnimationEnd, toastHeight]);

  const panResponder = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, gestureState) => gestureState.dy < -10,
      onPanResponderRelease: (_, gestureState) => {
        if (gestureState.dy < SWIPE_THRESHOLD) {
          Toast.hide();
        }
      },
    })
  ).current;

  const handleLayout = (event: LayoutChangeEvent) => {
    setToastHeight(event.nativeEvent.layout.height);
  };

  const getBackgroundColor = () => {
    if (toast.backgroundColor) return toast.backgroundColor;
    switch (toast.type) {
      case 'success':
        return '#4ade80';
      case 'error':
        return '#f87171';
      case 'info':
        return '#3b82f6';
      default:
        return '#333333';
    }
  };

  const getTextColor = () => toast.textColor || '#ffffff';

  return (
    <Animated.View
      {...panResponder.panHandlers}
      onLayout={handleLayout}
      accessible={true}
      accessibilityRole="alert"
      accessibilityLiveRegion="assertive"
      style={[
        styles.container,
        {
          backgroundColor: getBackgroundColor(),
          transform: [{ translateY }],
        },
      ]}
    >
      <Text style={[styles.text, { color: getTextColor() }]}>
        {toast.message}
      </Text>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 20,
    right: 20,
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 5,
    zIndex: 9999,
  },
  text: {
    fontWeight: '600',
    textAlign: 'center',
  },
});
